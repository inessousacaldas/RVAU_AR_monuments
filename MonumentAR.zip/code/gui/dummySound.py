# Funcion que reproduce un pitido de frecuencia conocida
# Sirve como dummy-function para los sistemas posix
def MessageBeep(frecuency):
    pass
