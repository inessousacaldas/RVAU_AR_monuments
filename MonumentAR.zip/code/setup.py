from setuptools import setup


setup(name='MySoftware',
     packages=['gui', 'vision']
)